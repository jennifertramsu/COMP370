# COMP370 Homework 8
- Politics
- IT/Technical Support
- Mental Health Advice
- School/Course Advice
- School Administration Advice
- Advertisements
- Internship/Research Advice
- Life Advice
- Complaint